package Five;

public class GroupException extends RuntimeException {

	public GroupException(String s) {
		super(s);

	}

}
