package Five;

public class NormalTicketBookingException extends RuntimeException {

	public NormalTicketBookingException(String s) {
		super(s);

	}

}
