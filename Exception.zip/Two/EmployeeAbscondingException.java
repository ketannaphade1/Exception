package Two;

public class EmployeeAbscondingException extends RuntimeException  {

	public EmployeeAbscondingException(String s){
		
		super(s);
		
	}
	
}
