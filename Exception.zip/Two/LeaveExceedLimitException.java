package Two;

public class LeaveExceedLimitException extends RuntimeException{

	public LeaveExceedLimitException(String s) {
		super(s);
	}

}
