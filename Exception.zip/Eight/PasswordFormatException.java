package Eight;

public class PasswordFormatException extends RuntimeException {

	public PasswordFormatException(String s) {

		super(s);
	}
}
