package Four;

public class Category {

	
	long catid;
	String categoryname;
	
	
}
