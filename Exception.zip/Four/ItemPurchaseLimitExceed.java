package Four;

public class ItemPurchaseLimitExceed extends RuntimeException {

	public ItemPurchaseLimitExceed(String s) {

		super(s);
	}

}
