package Four;

public class ItemBought {
	
	long itemid;
	int itemqty;
	
	
	
}
