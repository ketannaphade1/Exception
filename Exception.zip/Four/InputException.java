package Four;

public class InputException extends RuntimeException {

	public InputException(String s) {

		super(s);
	}

}
