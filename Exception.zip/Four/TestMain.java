package Four;

public class TestMain {

	public static void main(String[] args) {

		ItemAddition itemAddition = new ItemAddition();
		
		itemAddition.addItems();
		itemAddition.purchaseItems();
	

	}
}
