package one;

public class FailException extends RuntimeException  {

	
	public FailException(String s) {
		super(s);

	}
}
